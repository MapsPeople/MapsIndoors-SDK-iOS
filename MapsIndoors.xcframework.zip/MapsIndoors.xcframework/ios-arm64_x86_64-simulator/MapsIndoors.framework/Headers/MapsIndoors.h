#import <Foundation/Foundation.h>

//! Project version number for MapsIndoorsPublic.
FOUNDATION_EXPORT double MapsIndoorsVersionNumber;

//! Project version string for MapsIndoorsPublic.
FOUNDATION_EXPORT const unsigned char MapsIndoorsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MapsIndoors/PublicHeader.h>


