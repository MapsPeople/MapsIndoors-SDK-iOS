//
//  MapsIndoorsCodable.h
//  MapsIndoorsCodable
//
//  Created by Christian Wolf Johannsen on 14/03/2023.
//  Copyright © 2023 MapsPeople A/S. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MapsIndoorsCodable.
FOUNDATION_EXPORT double MapsIndoorsCodableVersionNumber;

//! Project version string for MapsIndoorsCodable.
FOUNDATION_EXPORT const unsigned char MapsIndoorsCodableVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MapsIndoorsCodable/PublicHeader.h>


